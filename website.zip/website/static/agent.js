$(document).ready(function(){
    $('#agent').removeClass('na_in');
    $('#agent').addClass('black');
});
$(document).ready(function(){
    $('#Dashboard').addClass('black');
    $('#Signout').addClass('white');
    $('#Activity').addClass('white');
    $('#Alerts').addClass('white');
    $('#Configure').addClass('white');
    $('#Users').addClass('white');

    function loadPage(){
    $('#monitors').load('/data.html');
    }
    loadPage();
    setInterval(loadPage, 1000)
    });

$('#Dashboard').click(function(){
    $('#Signout').removeClass('black');
    $('#Activity').removeClass('black');
    $('#Alerts').removeClass('black');
    $('#Configure').removeClass('black');
    $('#Users').removeClass('white');
    $('#Dashboard').removeClass('white');
        $('#Dashboard').addClass('black');
        $('#Signout').addClass('white');
        $('#Activity').addClass('white');
        $('#Alerts').addClass('white');
        $('#Configure').addClass('white');
        $('#Users').addClass('white');
})

$('#Activity').click(function(){
    $('#Signout').removeClass('black');
    $('#Alerts').removeClass('black');
    $('#Configure').removeClass('black');
    $('#Users').removeClass('black');
    $('#Activity').removeClass('white');
    $('#Dashboard').removeClass('black');
        $('#Dashboard').addClass('white');
        $('#Signout').addClass('white');
        $('#Activity').addClass('black');
        $('#Alerts').addClass('white');
        $('#Configure').addClass('white');
        $('#Users').addClass('white');
})

$('#Alerts').click(function(){
    $('#Signout').removeClass('black');
    $('#Alerts').removeClass('white');
    $('#Configure').removeClass('black');
    $('#Users').removeClass('black');
    $('#Activity').removeClass('black');
    $('#Dashboard').removeClass('black');
        $('#Dashboard').addClass('white');
        $('#Signout').addClass('white');
        $('#Activity').addClass('white');
        $('#Alerts').addClass('black');
        $('#Configure').addClass('white');
        $('#Users').addClass('white');
})
$('#Configure').click(function(){
    $('#Signout').removeClass('black');
    $('#Alerts').removeClass('black');
    $('#Configure').removeClass('white');
    $('#Users').removeClass('black');
    $('#Activity').removeClass('white');
    $('#Dashboard').removeClass('black');
        $('#Dashboard').addClass('white');
        $('#Signout').addClass('white');
        $('#Activity').addClass('white');
        $('#Alerts').addClass('white');
        $('#Configure').addClass('black');
        $('#Users').addClass('white');
})
$('#Signout').click(function(){
    $('#Signout').removeClass('white');
    $('#Alerts').removeClass('black');
    $('#Configure').removeClass('black');
    $('#Users').removeClass('black');
    $('#Activity').removeClass('white');
    $('#Dashboard').removeClass('black');
        $('#Dashboard').addClass('white');
        $('#Signout').addClass('black');
        $('#Activity').addClass('white');
        $('#Alerts').addClass('white');
        $('#Configure').addClass('white');
        $('#Users').addClass('white');
})
$('#Users').click(function(){
    $('#Signout').removeClass('black');
    $('#Alerts').removeClass('black');
    $('#Configure').removeClass('black');
    $('#Users').removeClass('white');
    $('#Activity').removeClass('white');
    $('#Dashboard').removeClass('black');
        $('#Dashboard').addClass('white');
        $('#Signout').addClass('white');
        $('#Activity').addClass('white');
        $('#Alerts').addClass('white');
        $('#Configure').addClass('white');
        $('#Users').addClass('black');
})


var ctx=document.getElementById('donutChart').getContext('2d');
var data={labels: ['Used', 'Free'], datasets:[{
     data:[usage.used, usage.free], backgroundColor:[
        'rgba(255,99,132,0.8)', 'rgba(54,255,132,0.8)', 'rgba(76,99,132,0.8)'
    ],hoverBackgroundColor:['rgba(255,99,132,0.8)', 'rgba(54,255,132,0.8)', 'rgba(76,99,132,0.8)']
}]
};
var myChart=new Chart(ctx, {
    type:'doughnut',
    data: data,
    options:{
        responsive: true, legend:{
            position:'top',
        }, title:{
        display: true,text: 'Chart'
        }, animation:{
         animateScale:true, animateRotate: true
}
}
});
##THIS WLL HAVE ALL THE LINKS TO THE DIFFIRENT PAGES
from flask import Flask, Blueprint, render_template, jsonify, redirect, request, session, Response,stream_with_context
import psutil
from flask_mysqldb import MySQL
import time
import collections
from threading import Thread
import threading
from datetime import datetime
from io import StringIO
import csv
import asyncio
import schedule


app=Flask(__name__)
app.secret_key="locked_hahahaha"
app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']=''
app.config['MYSQL_DB']='mother'

mysql=MySQL(app)
views= Blueprint('views', __name__)

#CALLING HOME PAGE FOR THE SYSTEM
@app.route('/')
def home():
    return render_template('home.html')
    #IF NO NAME PRESENT REDIRECT TO LOG IN PAGE
#LOG IN PAGE

@app.route('/login', methods=['GET', 'POST'])
def login():
    return render_template('login.html')

@app.route('/stats')
def stats():
    return render_template('stats.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')


@app.route('/constituency')
def constituency():
    return render_template('areas.html')

@app.route('/messages')
def messages():
    return render_template('messages.html')

@app.route('/chat')
def chat():
    return render_template('chat.html')

@app.route('/agents')
def agents():
    return render_template('agents.html')

@app.route('/reports')
def reports():
    return render_template('reports.html')

@app.route('/fielder')
def fielder():
    return render_template('fielder.html')


if __name__== '__main__':
    app.run( host='0.0.0.0',port=5000,debug=True,use_reloader=False)
    